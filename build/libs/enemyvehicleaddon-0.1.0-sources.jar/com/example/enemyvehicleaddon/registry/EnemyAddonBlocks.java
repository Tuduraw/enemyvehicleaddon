package com.example.enemyvehicleaddon.registry;

import com.example.enemyvehicleaddon.EnemyVehicleAddon;
import com.example.enemyvehicleaddon.block.EnemyControlBlock;
import com.example.enemyvehicleaddon.block.EnemySupplyBlock;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class EnemyAddonBlocks {

	public static class_2248 ENEMY_CONTROL;
	public static class_2248 ENEMY_SUPPLY;

	private EnemyAddonBlocks() {
	}

	/** Same block settings as the prerequisite mod's own Drone Center, apart from the map colour. */
	public static void register() {
		class_5321<class_2248> key = class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(EnemyVehicleAddon.MOD_ID, "enemy_control"));
		ENEMY_CONTROL = class_2378.method_39197(class_7923.field_41175, key,
				new EnemyControlBlock(class_4970.class_2251.method_9637()
						.method_63500(key)
						.method_31710(class_3620.field_16020)
						.method_9632(4.0f)
						.method_29292()));

		class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(EnemyVehicleAddon.MOD_ID, "enemy_control"));
		class_2378.method_39197(class_7923.field_41178, itemKey,
				new class_1747(ENEMY_CONTROL, new class_1792.class_1793().method_63686(itemKey).method_63685()));

		// Breakable like any sturdy block - destroying it is meant to be a way to ground an enemy base's aircraft.
		class_5321<class_2248> supplyKey = class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(EnemyVehicleAddon.MOD_ID, "enemy_supply"));
		ENEMY_SUPPLY = class_2378.method_39197(class_7923.field_41175, supplyKey,
				new EnemySupplyBlock(class_4970.class_2251.method_9637()
						.method_63500(supplyKey)
						.method_31710(class_3620.field_16010)
						.method_9632(4.0f)
						.method_29292()));
		class_5321<class_1792> supplyItemKey = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(EnemyVehicleAddon.MOD_ID, "enemy_supply"));
		class_2378.method_39197(class_7923.field_41178, supplyItemKey,
				new class_1747(ENEMY_SUPPLY, new class_1792.class_1793().method_63686(supplyItemKey).method_63685()));
	}
}
