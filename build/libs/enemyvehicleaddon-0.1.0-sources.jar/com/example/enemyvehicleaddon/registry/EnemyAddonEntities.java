package com.example.enemyvehicleaddon.registry;

import com.example.enemyvehicleaddon.EnemyVehicleAddon;
import com.example.enemyvehicleaddon.entity.EnemyPilotEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class EnemyAddonEntities {

	/** A separate type from the prerequisite mod's DUMMY_PILOT (same size, same renderer) so that a pilot saved to disk reloads as an EnemyPilotEntity - which, with no leash center known yet, deliberately does nothing until its Enemy Control Block replaces it - rather than as a plain DummyPilotEntity that would start engaging hostile mobs on its own. */
	public static class_1299<EnemyPilotEntity> ENEMY_PILOT;

	private EnemyAddonEntities() {
	}

	public static void register() {
		class_5321<class_1299<?>> key = class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(EnemyVehicleAddon.MOD_ID, "enemy_pilot"));
		// Matches the prerequisite mod's own DUMMY_PILOT registration (0.6 x 1.8, tracking range 32).
		ENEMY_PILOT = class_2378.method_39197(class_7923.field_41177, key,
				class_1299.class_1300.<EnemyPilotEntity>method_5903(EnemyPilotEntity::new, class_1311.field_17715)
						.method_17687(0.6f, 1.8f)
						.method_27299(32)
						.method_5905(key));
		FabricDefaultAttributeRegistry.register(ENEMY_PILOT, com.example.tudursvehiclemod.entity.DummyPilotEntity.createAttributes());
	}
}
