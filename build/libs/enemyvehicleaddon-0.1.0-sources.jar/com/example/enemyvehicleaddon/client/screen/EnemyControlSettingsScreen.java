package com.example.enemyvehicleaddon.client.screen;

import com.example.enemyvehicleaddon.block.EnemyControlBlockEntity;
import com.example.enemyvehicleaddon.network.EnemyControlSettingsUpdatePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Enemy Control Block's own settings (the "Enemy Settings" button on the Drone Center config screen): leash radius, the player whitelist, and structure-template arming.
 *
 * Edits are local until Save, which sends the complete settings in one payload (server-side sanitised, see EnemyControlBlockEntity#enemyvehicleaddon$setEnemySettings()); Cancel/Escape discards them. The whitelist is paged (ROWS_PER_PAGE names per page, prev/next) rather than scrolled - the same paging approach the prerequisite mod's own waypoint screen uses. All mutable state lives in fields so a window resize (which re-runs init()) keeps unsaved edits. */
public class EnemyControlSettingsScreen extends class_437 {

	private static final int ROWS_PER_PAGE = 4;
	private static final int ROW_HEIGHT = 22;
	private static final int PANEL_WIDTH = 300;

	private final int x;
	private final int y;
	private final int z;
	private final double originalRadius;
	private final List<String> whitelist;

	private String radiusText;
	/** Desired template state - sent with Save; the server may refuse arming (see EnemyControlBlockEntity#enemyvehicleaddon$armTemplate()) and reports the outcome in the action bar. */
	private boolean templateArmed;
	private String pendingName = "";
	private int page;
	/** Shown under the name field when the last Add attempt was rejected; cleared on the next successful add. */
	private class_2561 addError;

	private int top;
	private int left;

	public EnemyControlSettingsScreen(int x, int y, int z, double leashRadius, List<String> whitelist, boolean templateArmed) {
		super(class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.title"));
		this.x = x;
		this.y = y;
		this.z = z;
		this.originalRadius = leashRadius;
		this.radiusText = formatRadius(leashRadius);
		this.whitelist = new ArrayList<>(whitelist);
		this.templateArmed = templateArmed;
	}

	private static String formatRadius(double radius) {
		return radius == Math.rint(radius) ? Long.toString((long) radius) : Double.toString(radius);
	}

	private int pageCount() {
		return Math.max(1, (this.whitelist.size() + ROWS_PER_PAGE - 1) / ROWS_PER_PAGE);
	}

	@Override
	protected void method_25426() {
		this.left = this.field_22789 / 2 - PANEL_WIDTH / 2;
		this.top = Math.max(8, this.field_22790 / 2 - 133);
		this.page = Math.min(this.page, this.pageCount() - 1);

		// Leash radius
		class_342 radiusField = new class_342(this.field_22793, this.left + 150, this.top + 18, 150, 20,
				class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.radius"));
		radiusField.method_1880(9);
		radiusField.method_1852(this.radiusText);
		radiusField.method_1863(text -> this.radiusText = text);
		this.method_37063(radiusField);

		// Whitelist entry
		class_342 nameField = new class_342(this.field_22793, this.left, this.top + 58, 196, 20,
				class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.name"));
		nameField.method_1880(EnemyControlBlockEntity.MAX_NAME_LENGTH);
		nameField.method_1852(this.pendingName);
		nameField.method_1863(text -> this.pendingName = text);
		this.method_37063(nameField);
		this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.add"),
				button -> this.enemyvehicleaddon$addName()
		).method_46434(this.left + 200, this.top + 58, 100, 20).method_46431());

		// Current page of the whitelist - names are drawn in render(), only the remove buttons are widgets.
		int listTop = this.top + 94;
		int start = this.page * ROWS_PER_PAGE;
		for (int row = 0; row < ROWS_PER_PAGE; row++) {
			int index = start + row;
			if (index >= this.whitelist.size()) {
				break;
			}
			this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.remove"),
					button -> {
						this.whitelist.remove(index);
						this.method_41843();
					}
			).method_46434(this.left + 220, listTop + row * ROW_HEIGHT, 80, 20).method_46431());
		}

		// Paging
		int pagerY = listTop + ROWS_PER_PAGE * ROW_HEIGHT + 2;
		class_4185 prev = class_4185.method_46430(class_2561.method_43470("<"), button -> {
			this.page--;
			this.method_41843();
		}).method_46434(this.left, pagerY, 40, 20).method_46431();
		prev.field_22763 = this.page > 0;
		this.method_37063(prev);
		class_4185 next = class_4185.method_46430(class_2561.method_43470(">"), button -> {
			this.page++;
			this.method_41843();
		}).method_46434(this.left + PANEL_WIDTH - 40, pagerY, 40, 20).method_46431();
		next.field_22763 = this.page < this.pageCount() - 1;
		this.method_37063(next);

		// Structure template (see EnemyControlBlockEntity's template section)
		this.method_37063(class_4185.method_46430(this.enemyvehicleaddon$templateText(), button -> {
			this.templateArmed = !this.templateArmed;
			button.method_25355(this.enemyvehicleaddon$templateText());
		}).method_46434(this.left, pagerY + 38, PANEL_WIDTH, 20).method_46431());

		// Save / Cancel
		int buttonsY = pagerY + 62;
		this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.save"),
				button -> this.enemyvehicleaddon$save()
		).method_46434(this.left, buttonsY, PANEL_WIDTH / 2 - 2, 20).method_46431());
		this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.cancel"),
				button -> this.method_25419()
		).method_46434(this.left + PANEL_WIDTH / 2 + 2, buttonsY, PANEL_WIDTH / 2 - 2, 20).method_46431());

		this.method_48265(nameField);
	}

	/** Same acceptance rule the server applies (EnemyControlBlockEntity#enemyvehicleaddon$isAcceptableName()), plus duplicate and size checks, so the player sees a rejection immediately instead of the name silently vanishing on save. */
	private void enemyvehicleaddon$addName() {
		String name = this.pendingName.strip();
		if (!EnemyControlBlockEntity.enemyvehicleaddon$isAcceptableName(name)) {
			this.addError = class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.error.invalid");
			return;
		}
		String lower = name.toLowerCase(Locale.ROOT);
		for (String existing : this.whitelist) {
			if (existing.toLowerCase(Locale.ROOT).equals(lower)) {
				this.addError = class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.error.duplicate");
				return;
			}
		}
		if (this.whitelist.size() >= EnemyControlBlockEntity.MAX_WHITELIST_SIZE) {
			this.addError = class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.error.full");
			return;
		}
		this.whitelist.add(name);
		this.pendingName = "";
		this.addError = null;
		this.page = this.pageCount() - 1;
		this.method_41843();
	}

	/** An unparsable radius falls back to the value the screen was opened with; range clamping is left to the server. */
	private void enemyvehicleaddon$save() {
		double radius;
		try {
			radius = Double.parseDouble(this.radiusText.strip());
		} catch (NumberFormatException e) {
			radius = this.originalRadius;
		}
		ClientPlayNetworking.send(new EnemyControlSettingsUpdatePayload(this.x, this.y, this.z, radius, List.copyOf(this.whitelist), this.templateArmed));
		this.method_25419();
	}

	private class_2561 enemyvehicleaddon$templateText() {
		return class_2561.method_43469("gui.enemyvehicleaddon.enemy_settings.template",
				class_2561.method_43471(this.templateArmed ? "options.on" : "options.off"));
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		super.method_25394(context, mouseX, mouseY, delta);
		context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.top, 0xFFFFFFFF);

		context.method_27535(this.field_22793, class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.radius"),
				this.left, this.top + 24, 0xFFFFFFFF);
		context.method_27535(this.field_22793, class_2561.method_43469("gui.enemyvehicleaddon.enemy_settings.radius_range",
						formatRadius(EnemyControlBlockEntity.MIN_LEASH_RADIUS), formatRadius(EnemyControlBlockEntity.MAX_LEASH_RADIUS)),
				this.left, this.top + 44, 0xFFAAAAAA);

		if (this.addError != null) {
			context.method_27535(this.field_22793, this.addError, this.left, this.top + 82, 0xFFFF5555);
		} else {
			context.method_27535(this.field_22793, class_2561.method_43469("gui.enemyvehicleaddon.enemy_settings.whitelist_count",
					this.whitelist.size(), EnemyControlBlockEntity.MAX_WHITELIST_SIZE), this.left, this.top + 82, 0xFFAAAAAA);
		}

		int listTop = this.top + 94;
		int start = this.page * ROWS_PER_PAGE;
		for (int row = 0; row < ROWS_PER_PAGE; row++) {
			int index = start + row;
			if (index >= this.whitelist.size()) {
				break;
			}
			context.method_27535(this.field_22793, class_2561.method_43470(this.whitelist.get(index)),
					this.left + 4, listTop + row * ROW_HEIGHT + 6, 0xFFFFFFFF);
		}

		int pagerY = listTop + ROWS_PER_PAGE * ROW_HEIGHT + 2;
		context.method_27534(this.field_22793, class_2561.method_43470((this.page + 1) + " / " + this.pageCount()),
				this.field_22789 / 2, pagerY + 6, 0xFFFFFFFF);

		// The one behaviour most likely to surprise: an empty whitelist targets everyone, the owner included.
		class_2561 notice = this.whitelist.isEmpty()
				? class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.empty_warning")
				: class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.whitelist_note");
		context.method_27534(this.field_22793, notice, this.field_22789 / 2, pagerY + 25,
				this.whitelist.isEmpty() ? 0xFFFF5555 : 0xFFAAAAAA);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
