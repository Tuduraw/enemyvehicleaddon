package com.example.enemyvehicleaddon.structure;

import com.example.enemyvehicleaddon.EnemyVehicleAddon;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3773;
import net.minecraft.class_7151;
import net.minecraft.class_7923;

public final class EnemyStructures {

	public static class_7151<EnemyBaseStructure> ENEMY_BASE;
	public static class_3773 ENEMY_BASE_PIECE;

	private EnemyStructures() {
	}

	public static void register() {
		ENEMY_BASE = class_2378.method_10230(class_7923.field_41147, class_2960.method_60655(EnemyVehicleAddon.MOD_ID, "enemy_base"),
				(class_7151<EnemyBaseStructure>) () -> EnemyBaseStructure.CODEC);
		ENEMY_BASE_PIECE = class_2378.method_10230(class_7923.field_41146, class_2960.method_60655(EnemyVehicleAddon.MOD_ID, "enemy_base"),
				(class_3773.class_6615) EnemyBasePiece::new);
	}
}
