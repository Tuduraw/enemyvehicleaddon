package com.example.enemyvehicleaddon.structure;

import com.example.enemyvehicleaddon.block.EnemyControlBlock;
import com.example.enemyvehicleaddon.block.EnemyControlBlockEntity;
import com.example.enemyvehicleaddon.registry.EnemyAddonBlocks;
import java.util.EnumSet;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_2902;
import net.minecraft.class_3341;
import net.minecraft.class_3443;
import net.minecraft.class_5138;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_6625;

/** The single piece of an enemy base (EnemyBaseStructure). Everything it draws is a deterministic function of what it stores - anchor (world x/z of local (0, 0)), ground level, rotation and the definition - so each chunk it overlaps draws its own part independently, in any order, and the parts line up.
 *
 * Per column (only inside the chunk currently being generated):
 * - inside the footprint: levelled to the ground level - filled up (fill block, deep fill block below 4 layers) or cut down, everything above cleared (water included), topped with the definition's surface at y = -1;
 * - in the skirt around it (terrain.skirt blocks): blended linearly from the ground level back to the natural height, cutting/filling solid ground only (water left alone), topped with the terrain surface block where it changed.
 * Then boxes, blocks and units are drawn, each clipped to the chunk, and finally the chunk's heightmaps are recomputed (see refreshHeightmaps()). Units place an Enemy Control Block holding its (rotated) EnemyUnitSpec as a pending setup - nothing else happens until that block first ticks, i.e. until a player comes near (see EnemyControlBlockEntity). */
public class EnemyBasePiece extends class_3443 {

	private final int anchorX;
	private final int anchorZ;
	private final int groundY;
	private final int quarterTurns;
	private final EnemyBaseDefinition definition;

	public EnemyBasePiece(int anchorX, int anchorZ, int groundY, int quarterTurns, EnemyBaseDefinition definition) {
		super(EnemyStructures.ENEMY_BASE_PIECE, 0, computeBox(anchorX, anchorZ, groundY, quarterTurns, definition));
		this.anchorX = anchorX;
		this.anchorZ = anchorZ;
		this.groundY = groundY;
		this.quarterTurns = quarterTurns;
		this.definition = definition;
	}

	public EnemyBasePiece(class_2487 nbt) {
		super(EnemyStructures.ENEMY_BASE_PIECE, nbt);
		this.anchorX = nbt.method_68083("AnchorX", 0);
		this.anchorZ = nbt.method_68083("AnchorZ", 0);
		this.groundY = nbt.method_68083("GroundY", 64);
		this.quarterTurns = nbt.method_68083("QuarterTurns", 0);
		this.definition = nbt.method_67491("Definition", EnemyBaseDefinition.CODEC)
				.orElseThrow(() -> new IllegalStateException("Enemy base piece without a readable definition"));
	}

	@Override
	protected void method_14943(class_6625 context, class_2487 nbt) {
		nbt.method_10569("AnchorX", this.anchorX);
		nbt.method_10569("AnchorZ", this.anchorZ);
		nbt.method_10569("GroundY", this.groundY);
		nbt.method_10569("QuarterTurns", this.quarterTurns);
		nbt.method_67494("Definition", EnemyBaseDefinition.CODEC, this.definition);
	}

	private static class_3341 computeBox(int anchorX, int anchorZ, int groundY, int quarterTurns, EnemyBaseDefinition definition) {
		int skirt = definition.terrain().skirt();
		int[] corner = EnemyRotation.rotate(definition.sizeX() - 1, definition.sizeZ() - 1, quarterTurns);
		int minX = Math.min(anchorX, anchorX + corner[0]) - skirt;
		int maxX = Math.max(anchorX, anchorX + corner[0]) + skirt;
		int minZ = Math.min(anchorZ, anchorZ + corner[1]) - skirt;
		int maxZ = Math.max(anchorZ, anchorZ + corner[1]) + skirt;
		return new class_3341(minX, groundY - definition.terrain().maxFill() - 6, minZ,
				maxX, groundY + Math.max(definition.maxLocalY(), definition.terrain().maxCut()) + 2, maxZ);
	}

	private class_2338 toWorld(int localX, int localY, int localZ) {
		int[] xz = EnemyRotation.rotate(localX, localZ, this.quarterTurns);
		return new class_2338(this.anchorX + xz[0], this.groundY + localY, this.anchorZ + xz[1]);
	}

	@Override
	public void method_14931(class_5281 world, class_5138 structureAccessor, class_2794 chunkGenerator,
			class_5819 random, class_3341 chunkBox, class_1923 chunkPos, class_2338 pivot) {
		long start = System.nanoTime();
		this.draw(world, chunkBox);
		if (com.example.enemyvehicleaddon.config.EnemyAddonConfig.get().logGenerationTimings) {
			org.slf4j.LoggerFactory.getLogger("enemyvehicleaddon").info("[timings] enemy base chunk {}: {} ms", chunkPos,
					String.format("%.2f", (System.nanoTime() - start) / 1.0e6));
		}
	}

	private void draw(class_5281 world, class_3341 chunkBox) {
		this.gradeTerrain(world, chunkBox);
		class_2470 rotation = EnemyRotation.toBlockRotation(this.quarterTurns);
		for (EnemyBaseDefinition.Box box : this.definition.boxes()) {
			this.drawBox(world, chunkBox, box, rotation);
		}
		for (EnemyBaseDefinition.Block block : this.definition.blocks()) {
			this.place(world, chunkBox, block.pos().method_10263(), block.pos().method_10264(), block.pos().method_10260(), block.state().method_26186(rotation));
		}
		for (EnemyUnitSpec unit : this.definition.units()) {
			class_2338 pos = this.toWorld(unit.block().method_10263(), unit.block().method_10264(), unit.block().method_10260());
			if (!chunkBox.method_14662(pos)) {
				continue;
			}
			class_2680 state = EnemyAddonBlocks.ENEMY_CONTROL.method_9564()
					.method_11657(EnemyControlBlock.FACING, rotation.method_10503(class_2350.field_11043));
			world.method_8652(pos, state, class_2248.field_31028);
			if (world.method_8321(pos) instanceof EnemyControlBlockEntity blockEntity) {
				blockEntity.enemyvehicleaddon$setPendingSetup(unit.rotated(this.quarterTurns));
			}
		}
		// Last, after everything is drawn - see refreshHeightmaps()'s doc.
		refreshHeightmaps(world, chunkBox);
	}

	private void place(class_5281 world, class_3341 chunkBox, int localX, int localY, int localZ, class_2680 state) {
		class_2338 pos = this.toWorld(localX, localY, localZ);
		if (chunkBox.method_14662(pos)) {
			world.method_8652(pos, state, class_2248.field_31028);
		}
	}

	private void drawBox(class_5281 world, class_3341 chunkBox, EnemyBaseDefinition.Box box, class_2470 rotation) {
		int minX = Math.min(box.from().method_10263(), box.to().method_10263());
		int maxX = Math.max(box.from().method_10263(), box.to().method_10263());
		int minY = Math.min(box.from().method_10264(), box.to().method_10264());
		int maxY = Math.max(box.from().method_10264(), box.to().method_10264());
		int minZ = Math.min(box.from().method_10260(), box.to().method_10260());
		int maxZ = Math.max(box.from().method_10260(), box.to().method_10260());
		// Every chunk of the base calls this for every box - skip the whole volume at once when it does not reach this chunk.
		if (!class_3341.method_34390(this.toWorld(minX, minY, minZ), this.toWorld(maxX, maxY, maxZ)).method_14657(chunkBox)) {
			return;
		}
		class_2680 state = box.block().method_26186(rotation);
		for (int x = minX; x <= maxX; x++) {
			for (int z = minZ; z <= maxZ; z++) {
				boolean side = x == minX || x == maxX || z == minZ || z == maxZ;
				for (int y = minY; y <= maxY; y++) {
					boolean draw = switch (box.mode()) {
						case "hollow" -> side || y == minY || y == maxY;
						case "walls" -> side;
						default -> true;
					};
					if (draw) {
						this.place(world, chunkBox, x, y, z, state);
					}
				}
			}
		}
	}

	private void gradeTerrain(class_5281 world, class_3341 chunkBox) {
		EnemyBaseDefinition.Terrain terrain = this.definition.terrain();
		int skirt = terrain.skirt();
		int inverse = 4 - this.quarterTurns;
		class_2338.class_2339 mutable = new class_2338.class_2339();
		class_3341 box = this.method_14935();
		for (int x = Math.max(box.method_35415(), chunkBox.method_35415()); x <= Math.min(box.method_35418(), chunkBox.method_35418()); x++) {
			for (int z = Math.max(box.method_35417(), chunkBox.method_35417()); z <= Math.min(box.method_35420(), chunkBox.method_35420()); z++) {
				int[] local = EnemyRotation.rotate(x - this.anchorX, z - this.anchorZ, inverse);
				int outsideX = local[0] < 0 ? -local[0] : Math.max(0, local[0] - (this.definition.sizeX() - 1));
				int outsideZ = local[1] < 0 ? -local[1] : Math.max(0, local[1] - (this.definition.sizeZ() - 1));
				int outside = Math.max(outsideX, outsideZ);
				if (outside > skirt) {
					continue;
				}
				// "First free block above the ground" - ground ignoring water, and the top including water.
				int ground = world.method_8624(class_2902.class_2903.field_13195, x, z);
				int top = world.method_8624(class_2902.class_2903.field_13194, x, z);
				boolean inside = outside == 0;
				int target = inside ? this.groundY
						: (int) Math.round(this.groundY + (ground - this.groundY) * (outside / (double) (skirt + 1)));
				if (!inside && ground == target) {
					continue;
				}
				class_2680 surface = inside ? this.definition.surfaceAt(local[0], local[1]) : terrain.surfaceBlock();
				// Fill up to the new surface.
				for (int y = ground; y < target - 1; y++) {
					world.method_8652(mutable.method_10103(x, y, z), y < target - 4 ? terrain.deepFillBlock() : terrain.fillBlock(), class_2248.field_31028);
				}
				world.method_8652(mutable.method_10103(x, target - 1, z), surface, class_2248.field_31028);
				// Cut down to it: inside the footprint everything above goes (water too); in the skirt only solid ground.
				int clearTo = inside ? Math.max(ground, top) : ground;
				for (int y = target; y < clearTo; y++) {
					world.method_8652(mutable.method_10103(x, y, z), class_2246.field_10124.method_9564(), class_2248.field_31028);
				}
				// Whatever stood ON the old surface - see CLEAR_ABOVE_HEIGHT's doc. Only where the ground was actually lowered (or inside the footprint, which must be clear anyway).
				if (inside || ground > target) {
					int clearTop = Math.min(Math.max(ground, top) + CLEAR_ABOVE_HEIGHT, world.method_31600());
					for (int y = Math.max(target, clearTo); y <= clearTop; y++) {
						if (!world.method_8320(mutable.method_10103(x, y, z)).method_26215()) {
							world.method_8652(mutable, class_2246.field_10124.method_9564(), class_2248.field_31028);
						}
					}
				}
			}
		}
	}

	/** How far above the old ground level cleared columns are also emptied: vegetation placed from a NEIGHBOURING chunk (grass patches, flowers, trees reaching across the chunk border) can land on the original terrain before this chunk's own base part is drawn - after grading lowered the ground under it, it would float. Tall enough for ordinary trees. */
	private static final int CLEAR_ABOVE_HEIGHT = 32;

	/** Recomputes this chunk's heightmaps after grading. Vegetation is placed after structures, at positions taken from the chunk's heightmaps - but a chunk still being generated only keeps some heightmaps up to date on block changes, so the ones vegetation placement reads could still describe the ORIGINAL terrain: plants were placed at the old surface height, hanging in the air above the lowered ground (or buried in the raised one). Recomputing every heightmap the chunk has makes later placement see the graded surface. */
	private static void refreshHeightmaps(class_5281 world, class_3341 chunkBox) {
		class_2791 chunk = world.method_8392(chunkBox.method_35415() >> 4, chunkBox.method_35417() >> 4);
		EnumSet<class_2902.class_2903> types = EnumSet.noneOf(class_2902.class_2903.class);
		for (class_2902.class_2903 type : class_2902.class_2903.values()) {
			if (chunk.method_39295(type)) {
				types.add(type);
			}
		}
		if (!types.isEmpty()) {
			class_2902.method_16684(chunk, types);
		}
	}
}
