package com.example.enemyvehicleaddon.link;

import com.example.tudursvehiclemod.entity.AbstractVehicleEntity;
import net.minecraft.class_1297;
import net.minecraft.class_3218;

/** "Is this an enemy vehicle?" - the vehicle currently registered for some Enemy Control Block in its dimension (EnemyLinkState), which also covers a destroyed one until it is respawned. */
public final class EnemyVehicles {

	private EnemyVehicles() {
	}

	public static boolean isEnemy(class_1297 entity) {
		return entity instanceof AbstractVehicleEntity vehicle
				&& vehicle.method_73183() instanceof class_3218 world
				&& EnemyLinkState.get(world).isEnemyVehicle(vehicle.method_5667());
	}
}
