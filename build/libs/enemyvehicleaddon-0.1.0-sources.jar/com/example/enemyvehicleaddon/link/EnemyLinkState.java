package com.example.enemyvehicleaddon.link;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_4844;

/** Per-dimension record of every Enemy Control Block and the vehicle bound to it, kept OUTSIDE both the block entity and the vehicle entity because the whole point is to reason about one of them while the other is not loaded (see EnemyLinkManager). Saved as data/enemyvehicleaddon_links.dat in the dimension's folder. */
public class EnemyLinkState extends class_18 {

	public enum Mode {
		/** Nothing is force-loaded for this link: the vehicle only moves while players keep its chunk loaded. */
		DORMANT,
		/** Engaged with a target - vehicle (and block) chunks kept loaded. */
		PURSUIT,
		/** Pursuit ended, flying back to its route - still kept loaded until back on it (or timed out). */
		RETURNING
	}

	/** Mutable runtime view of one link. Fields below the blank line are transient (not saved) - see EnemyLinkManager for their use. */
	public static final class Link {
		final class_2338 blockPos;
		UUID vehicleUuid;
		/** ChunkPos#toLong() of where the vehicle was last seen, or null if never seen. */
		Long lastVehicleChunk;
		Mode mode;
		/** Horizontal distance from the block at the moment pursuit began - the vehicle was on its circular orbit then, so this is "the orbit" to get back to (routes with waypoints use the waypoints instead). */
		double returnOrbitRadius;
		/** World time the current mode began. */
		long modeSince;

		long lastEngagedTime = Long.MIN_VALUE / 2;
		long verifyUntil;
		long nextVerifyAllowed;

		Link(class_2338 blockPos) {
			this.blockPos = blockPos.method_10062();
			this.mode = Mode.DORMANT;
		}

		public class_2338 blockPos() {
			return this.blockPos;
		}

		public UUID vehicleUuid() {
			return this.vehicleUuid;
		}

		public Mode mode() {
			return this.mode;
		}
	}

	private record LinkData(class_2338 pos, Optional<UUID> vehicle, Optional<Long> lastVehicleChunk, String mode,
			double returnOrbitRadius, long modeSince) {

		static final Codec<LinkData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
				class_2338.field_25064.fieldOf("pos").forGetter(LinkData::pos),
				class_4844.field_40825.optionalFieldOf("vehicle").forGetter(LinkData::vehicle),
				Codec.LONG.optionalFieldOf("last_vehicle_chunk").forGetter(LinkData::lastVehicleChunk),
				Codec.STRING.optionalFieldOf("mode", Mode.DORMANT.name()).forGetter(LinkData::mode),
				Codec.DOUBLE.optionalFieldOf("return_orbit_radius", 0.0).forGetter(LinkData::returnOrbitRadius),
				Codec.LONG.optionalFieldOf("mode_since", 0L).forGetter(LinkData::modeSince)
		).apply(instance, LinkData::new));
	}

	public static final Codec<EnemyLinkState> CODEC = LinkData.CODEC.listOf().fieldOf("links").codec()
			.xmap(EnemyLinkState::fromData, EnemyLinkState::toData);

	/** DataFixTypes null: this is addon-own data with nothing to fix; Fabric API explicitly supports a null type here. */
	public static final class_10741<EnemyLinkState> TYPE =
			new class_10741<>("enemyvehicleaddon_links", EnemyLinkState::new, CODEC, null);

	private final Map<Long, Link> links = new ConcurrentHashMap<>();

	public EnemyLinkState() {
	}

	public static EnemyLinkState get(class_3218 world) {
		return world.method_17983().method_17924(TYPE);
	}

	private static EnemyLinkState fromData(List<LinkData> data) {
		EnemyLinkState state = new EnemyLinkState();
		for (LinkData entry : data) {
			Link link = new Link(entry.pos());
			link.vehicleUuid = entry.vehicle().orElse(null);
			link.lastVehicleChunk = entry.lastVehicleChunk().orElse(null);
			try {
				link.mode = Mode.valueOf(entry.mode());
			} catch (IllegalArgumentException e) {
				link.mode = Mode.DORMANT;
			}
			link.returnOrbitRadius = entry.returnOrbitRadius();
			link.modeSince = entry.modeSince();
			state.links.put(link.blockPos.method_10063(), link);
		}
		return state;
	}

	private List<LinkData> toData() {
		List<LinkData> data = new ArrayList<>();
		for (Link link : this.links.values()) {
			data.add(new LinkData(link.blockPos, Optional.ofNullable(link.vehicleUuid), Optional.ofNullable(link.lastVehicleChunk),
					link.mode.name(), link.returnOrbitRadius, link.modeSince));
		}
		return data;
	}

	public Link get(class_2338 pos) {
		return this.links.get(pos.method_10063());
	}

	public Link getOrCreate(class_2338 pos) {
		return this.links.computeIfAbsent(pos.method_10063(), key -> {
			this.method_80();
			return new Link(pos);
		});
	}

	public void remove(class_2338 pos) {
		if (this.links.remove(pos.method_10063()) != null) {
			this.vehicleIndex = null;
			this.method_80();
		}
	}

	/** Vehicle UUIDs of all links - rebuilt lazily after any change (see setVehicle()/remove()), since isEnemyVehicle() runs for every supply cycle, every enemy projectile explosion and every vehicle explosion, and the number of links grows with every generated base ever visited. */
	private volatile java.util.Set<UUID> vehicleIndex;

	/** The only way a link's vehicle is changed (keeps the index current). */
	public void setVehicle(Link link, UUID vehicleUuid) {
		link.vehicleUuid = vehicleUuid;
		this.vehicleIndex = null;
		this.method_80();
	}

	/** Whether uuid is the vehicle currently registered for any Enemy Control Block in this dimension. */
	public boolean isEnemyVehicle(UUID uuid) {
		java.util.Set<UUID> index = this.vehicleIndex;
		if (index == null) {
			java.util.Set<UUID> rebuilt = new java.util.HashSet<>();
			for (Link link : this.links.values()) {
				if (link.vehicleUuid != null) {
					rebuilt.add(link.vehicleUuid);
				}
			}
			index = rebuilt;
			this.vehicleIndex = index;
		}
		return index.contains(uuid);
	}

	public Collection<Link> all() {
		return this.links.values();
	}
}
