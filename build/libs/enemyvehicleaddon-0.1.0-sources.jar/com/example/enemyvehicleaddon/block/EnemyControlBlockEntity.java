package com.example.enemyvehicleaddon.block;

import com.example.enemyvehicleaddon.entity.EnemyPilotEntity;
import com.example.enemyvehicleaddon.mixin.BlockEntityAccessor;
import com.example.enemyvehicleaddon.structure.EnemyUnitSpec;
import com.example.enemyvehicleaddon.registry.EnemyAddonBlockEntities;
import com.example.tudursvehiclemod.asset.VehicleDefinition;
import com.example.tudursvehiclemod.asset.VehicleRegistry;
import com.example.tudursvehiclemod.block.DroneCenterBlockEntity;
import com.example.tudursvehiclemod.block.DroneWaypoint;
import com.example.tudursvehiclemod.block.GroundWaypoint;
import com.example.tudursvehiclemod.entity.AbstractVehicleEntity;
import com.example.tudursvehiclemod.item.DroneControlStickItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_7923;

/** Everything a Drone Center stores and does (inherited unchanged), plus this block's own enemy settings (owner, leash radius, the player whitelist its EnemyPilotEntity must not attack) and the respawn of a lost vehicle (see the respawn section below). */
public class EnemyControlBlockEntity extends DroneCenterBlockEntity {

	private static final Logger LOGGER = LoggerFactory.getLogger("enemyvehicleaddon");

	public static final double DEFAULT_LEASH_RADIUS = 1000.0;
	public static final double MIN_LEASH_RADIUS = 16.0;
	public static final double MAX_LEASH_RADIUS = 100000.0;
	public static final int MAX_WHITELIST_SIZE = 256;
	/** Vanilla names are at most 16 characters; the extra headroom tolerates prefixed names some proxies (e.g. Geyser/Floodgate) produce. */
	public static final int MAX_NAME_LENGTH = 32;

	/** The player who placed this block, or null (placed by something other than a player, e.g. a future structure generator) - see enemyvehicleaddon$canManage(). */
	private UUID owner;
	private double leashRadius = DEFAULT_LEASH_RADIUS;
	/** As entered (original capitalisation kept for display). */
	private List<String> whitelist = List.of();
	/** Lower-cased copy of whitelist, rebuilt whenever it changes and shared (read-only) with the seated pilot. */
	private Set<String> whitelistLowerCase = Set.of();

	/** DroneCenterBlockEntity's only constructor hardcodes the prerequisite mod's DRONE_CENTER type, so the type is replaced right after super() returns (enemyvehicleaddon$prepareSuperConstructor() makes sure this block is among DRONE_CENTER's supported blocks, which is what lets super() accept this block's state in the first place). From here on getType() is ENEMY_CONTROL - which is what gets written as this block entity's saved id, and what the ticker lookup is matched against. */
	public EnemyControlBlockEntity(class_2338 pos, class_2680 state) {
		super(pos, enemyvehicleaddon$prepareSuperConstructor(state));
		((BlockEntityAccessor) this).enemyvehicleaddon$setType(EnemyAddonBlockEntities.ENEMY_CONTROL);
		// An enemy vehicle that lands to resupply (see EnemySupplyBlock) should take off again on its own once full - the prerequisite mod's default (MANUAL_REENABLE) would leave it grounded for good. Only a default for a freshly created block: a saved block's own setting is restored by readData() afterwards, and can still be changed from the Drone Center screens.
		this.tudursvehiclemod$setAutoDisableResumeMode(DroneCenterBlockEntity.AutoDisableResumeMode.AUTO_RESUME);
	}

	/** Runs before DroneCenterBlockEntity's (and so BlockEntity's) constructor - see EnemyAddonBlockEntities#enemyvehicleaddon$ensureDroneCenterSupportsEnemyBlock(). Normally already done by then; this only guarantees it. */
	private static class_2680 enemyvehicleaddon$prepareSuperConstructor(class_2680 state) {
		EnemyAddonBlockEntities.enemyvehicleaddon$ensureDroneCenterSupportsEnemyBlock();
		return state;
	}

	/** Template placement first (a freshly placed template copy must set itself up before anything else looks at it - see the template section), then link bookkeeping (see EnemyLinkManager#onBlockEntityTick()), then respawn handling, then the inherited Drone Center tick, then the settings push. Respawn runs BEFORE the inherited tick so that a vehicle respawned (and re-activated) this tick is linked by that same inherited tick right away. */
	public static void tick(class_1937 world, class_2338 pos, class_2680 state, EnemyControlBlockEntity blockEntity) {
		if (world instanceof class_3218 serverWorld) {
			blockEntity.enemyvehicleaddon$applyPendingSetup(serverWorld);
			blockEntity.enemyvehicleaddon$updateTemplatePlacement(serverWorld, state);
			com.example.enemyvehicleaddon.link.EnemyLinkManager.onBlockEntityTick(serverWorld, blockEntity);
			blockEntity.enemyvehicleaddon$updateRespawn(serverWorld);
		}
		DroneCenterBlockEntity.tick(world, pos, state, blockEntity);
		if (world instanceof class_3218 serverWorld) {
			blockEntity.enemyvehicleaddon$pushSettingsToPilot(serverWorld);
		}
	}

	/** Keeps an already-seated pilot current, so a whitelist/radius change applies without a deactivate/reactivate cycle (the pilot's creation-time settings come from enemyvehicleaddon$applySettingsTo() instead). Two map lookups per tick - the same lookups the inherited tick already does. */
	private void enemyvehicleaddon$pushSettingsToPilot(class_3218 world) {
		AbstractVehicleEntity vehicle = DroneCenterBlockEntity.tudursvehiclemod$findBoundVehicle(world, this.tudursvehiclemod$getBoundVehicleId());
		if (vehicle != null && vehicle.tudursvehiclemod$getSeatOccupant(0) instanceof EnemyPilotEntity pilot) {
			this.enemyvehicleaddon$applySettingsTo(pilot);
		}
	}

	/** Called from DroneCenterBlockEntityMixin when the pilot is created, and every tick afterwards via enemyvehicleaddon$pushSettingsToPilot(). */
	public void enemyvehicleaddon$applySettingsTo(EnemyPilotEntity pilot) {
		pilot.enemyvehicleaddon$setEnemySettings(this.method_11016(), this.leashRadius, this.whitelistLowerCase);
	}

	// --- Respawn ---
	//
	// While this block exists and still holds its Drone Control Stick, a bound vehicle that is destroyed (or confirmed gone - see EnemyLinkManager's vehicle verification) is replaced after EnemyAddonConfig#respawnDelaySeconds of WORLD time (default 5 minutes). World time keeps running while this block is unloaded, so the replacement simply appears the next time the block is loaded after the deadline - "re-deployed while you were away".
	//
	// What to respawn is remembered whenever the vehicle is seen: its definition id always, and its pose (position relative to this block + yaw) at the moment it is first seen active AND stationary - i.e. parked, right after activation. Without a recorded pose (activated while already airborne and never parked since), the prerequisite mod's own Home Point is used instead (which it captures from the vehicle's position when the stick is inserted), with yaw 0.
	//
	// Removing the stick cancels any pending respawn; that is the way to retire an enemy for good without breaking the block.

	/** Definition id of the vehicle to respawn, or null if no vehicle has been seen yet. */
	private class_2960 respawnVehicleId;
	/** Parked pose relative to this block (x, y, z offset from the block's minimum corner; yaw), or null - see the section doc above. */
	private double[] respawnPose;
	/** Which vehicle respawnPose was recorded from - a newly bound or respawned vehicle is recorded afresh. */
	private UUID respawnPoseRecordedFor;
	/** World time at which the lost vehicle is replaced, or -1 while nothing is pending. */
	private long respawnAt = -1L;

	/** Horizontal speed below which a vehicle counts as parked - the same threshold the prerequisite mod uses for "stationary" resupply. */
	private static final double PARKED_VELOCITY_SQUARED = 0.02 * 0.02;

	private void enemyvehicleaddon$updateRespawn(class_3218 world) {
		UUID bound = this.tudursvehiclemod$getBoundVehicleId();
		if (bound == null) {
			// Stick removed: see the section doc above.
			if (this.respawnAt >= 0) {
				this.respawnAt = -1L;
				this.method_5431();
			}
			return;
		}
		long now = world.method_75260();
		AbstractVehicleEntity vehicle = DroneCenterBlockEntity.tudursvehiclemod$findBoundVehicle(world, bound);
		if (vehicle != null && !vehicle.tudursvehiclemod$isDestroyed()) {
			this.enemyvehicleaddon$remember(vehicle, bound);
			if (this.respawnAt >= 0) {
				// It turned up after all (e.g. a verification that ran while it was out of reach).
				this.respawnAt = -1L;
				this.method_5431();
			}
			return;
		}
		if (vehicle != null && this.respawnAt < 0) {
			// Destroyed. The inherited tick deactivates this block for it right after this.
			this.enemyvehicleaddon$scheduleRespawn(now);
		}
		if (this.respawnAt >= 0 && now >= this.respawnAt) {
			this.respawnAt = -1L;
			this.method_5431();
			if (!this.enemyvehicleaddon$respawn(world, vehicle)) {
				LOGGER.warn("Enemy Control Block at {} could not respawn its vehicle ({}).", this.method_11016(), this.respawnVehicleId);
			}
		}
	}

	/** Called by EnemyLinkManager when a verification confirms the bound vehicle no longer exists. */
	public void enemyvehicleaddon$onVehicleConfirmedMissing(class_3218 world) {
		if (this.respawnAt < 0) {
			this.enemyvehicleaddon$scheduleRespawn(world.method_75260());
		}
	}

	private void enemyvehicleaddon$scheduleRespawn(long now) {
		int delaySeconds = com.example.enemyvehicleaddon.config.EnemyAddonConfig.get().respawnDelaySeconds;
		if (delaySeconds <= 0 || this.respawnVehicleId == null) {
			return;
		}
		this.respawnAt = now + delaySeconds * 20L;
		this.method_5431();
	}

	private void enemyvehicleaddon$remember(AbstractVehicleEntity vehicle, UUID bound) {
		class_2960 definitionId = vehicle.getVehicleDefinitionId();
		if (definitionId != null && !definitionId.equals(this.respawnVehicleId)) {
			this.respawnVehicleId = definitionId;
			this.method_5431();
		}
		if (!bound.equals(this.respawnPoseRecordedFor) && this.tudursvehiclemod$isActive()
				&& vehicle.method_18798().method_37268() <= PARKED_VELOCITY_SQUARED) {
			class_2338 pos = this.method_11016();
			this.respawnPose = new double[]{vehicle.method_23317() - pos.method_10263(), vehicle.method_23318() - pos.method_10264(), vehicle.method_23321() - pos.method_10260(), vehicle.method_36454()};
			this.respawnPoseRecordedFor = bound;
			this.method_5431();
		}
	}

	/** Spawns a fresh vehicle at the remembered pose (full fuel/ammo), re-points the stick in slot 0 at it, removes the old wreck if it is still around, and re-activates this block (or, under redstone control, re-syncs with the current redstone signal instead). */
	private boolean enemyvehicleaddon$respawn(class_3218 world, AbstractVehicleEntity wreck) {
		class_1799 stick = this.method_5438(0);
		if (this.respawnVehicleId == null || !(stick.method_7909() instanceof DroneControlStickItem)) {
			return false;
		}
		Optional<VehicleDefinition> definition = VehicleRegistry.get(this.respawnVehicleId);
		if (definition.isEmpty()) {
			return false;
		}
		class_2338 pos = this.method_11016();
		double x;
		double y;
		double z;
		float yaw;
		if (this.respawnPose != null) {
			x = pos.method_10263() + this.respawnPose[0];
			y = pos.method_10264() + this.respawnPose[1];
			z = pos.method_10260() + this.respawnPose[2];
			yaw = (float) this.respawnPose[3];
		} else {
			DroneWaypoint home = this.tudursvehiclemod$getHomePoint();
			x = pos.method_10263() + 0.5 + (home != null ? home.relX() : 0);
			y = pos.method_10264() + (home != null ? home.relY() : 1);
			z = pos.method_10260() + 0.5 + (home != null ? home.relZ() : 0);
			yaw = 0f;
		}
		class_2960 definitionId = this.respawnVehicleId;
		class_1299<?> entityType = class_7923.field_41177.method_63535(definition.get().entityType());
		// Same creation path as the prerequisite mod's own vehicle spawner (ModNetworking#handleSelectVehicle()).
		class_1297 created = entityType.method_5888(world, spawned -> {
			if (spawned instanceof AbstractVehicleEntity spawnedVehicle) {
				spawnedVehicle.setVehicleDefinitionId(definitionId);
			}
		}, class_2338.method_49637(x, y, z), class_3730.field_16465, false, false);
		if (!(created instanceof AbstractVehicleEntity newVehicle)) {
			if (created != null) {
				created.method_31472();
			}
			return false;
		}
		newVehicle.method_5808(x, y, z, yaw, 0f);
		newVehicle.tudursvehiclemod$fillAllWeaponAmmoAndFuel();
		newVehicle.tudursvehiclemod$syncWeaponAmmo();
		if (wreck != null) {
			wreck.method_31472();
		}
		world.method_8649(newVehicle);

		// Edited in place rather than through setStack(): setStack() would re-capture the Home Point from the new vehicle's position, overwriting a custom Home Point.
		DroneControlStickItem.setRegisteredVehicleId(stick, newVehicle.method_5667());
		this.respawnPoseRecordedFor = newVehicle.method_5667();
		this.method_5431();

		if (this.tudursvehiclemod$isRedstoneControlEnabled()) {
			this.tudursvehiclemod$onRedstonePowerChanged(world, world.method_49803(pos));
		} else if (!this.tudursvehiclemod$isActive()) {
			this.tudursvehiclemod$toggleActive(world);
		}
		return true;
	}

	// --- Pending setup (generated bases) ---
	//
	// A block placed by an enemy base structure (structure.EnemyBasePiece) carries an EnemyUnitSpec instead of a configured Drone Center: world generation runs without a live world, so nothing that needs one (spawning, the prerequisite mod's own setters that touch the world) can happen there. The spec is applied on this block's first tick - i.e. once a player comes near, in line with the dormancy policy - and the vehicle spawned exactly like a respawn.

	private EnemyUnitSpec pendingSetup;

	/** Called during world generation - stores only; see the section doc above. */
	public void enemyvehicleaddon$setPendingSetup(EnemyUnitSpec spec) {
		this.pendingSetup = spec;
		this.method_5431();
	}

	private void enemyvehicleaddon$applyPendingSetup(class_3218 world) {
		EnemyUnitSpec spec = this.pendingSetup;
		if (spec == null) {
			return;
		}
		this.pendingSetup = null;
		if (!(this.method_5438(0).method_7909() instanceof DroneControlStickItem)) {
			this.method_5447(0, new class_1799(com.example.tudursvehiclemod.item.ModItems.DRONE_CONTROL_STICK));
		}
		this.tudursvehiclemod$setWaypoints(spec.waypoints());
		this.tudursvehiclemod$setGroundWaypoints(spec.groundWaypoints());
		spec.home().ifPresent(this::tudursvehiclemod$setHomePoint);
		this.tudursvehiclemod$setReturnViaPoint(spec.via().orElse(null));
		EnemyUnitSpec.Orbit orbit = spec.orbit();
		this.tudursvehiclemod$setConfig(world, orbit.speedFraction(), orbit.orbitAltitude(), orbit.radiusMultiplier());
		EnemyUnitSpec.Combat combat = spec.combat();
		this.tudursvehiclemod$setDummyPilotCombatConfig(combat.weaponIndex(), combat.attackStartAltitude(), combat.attackStopAltitude(),
				combat.searchRange(), combat.diveTargetYOffset());
		this.tudursvehiclemod$setDummyPilotConfig(world, combat.weaponIndex() >= 0, this.tudursvehiclemod$getDummyPilotSkinId(), false, "");
		this.enemyvehicleaddon$setEnemySettings(spec.leashRadius(), List.of());
		this.owner = null;
		this.respawnVehicleId = spec.vehicle();
		// Spec parking offsets are from the block's centre; the respawn pose is stored from its corner.
		this.respawnPose = new double[]{0.5 + spec.parking().get(0), spec.parking().get(1), 0.5 + spec.parking().get(2), spec.parkingYaw()};
		this.respawnPoseRecordedFor = null;
		this.respawnAt = -1L;
		this.method_5431();
		if (!this.enemyvehicleaddon$respawn(world, null)) {
			LOGGER.warn("Generated Enemy Control Block at {} could not spawn its vehicle ({}) - is the vehicle pack installed?", this.method_11016(), spec.vehicle());
		}
	}

	// --- Structure template ---
	//
	// "Arming" a configured enemy block (from the enemy settings screen) marks its current setup - vehicle type and parked pose (from the respawn record), routes, Home Point, return via point, and every inherited Drone Center / dummy pilot / enemy setting - as a structure template. Save the surroundings with a structure block (vehicles excluded - only blocks are needed); every copy placed from it later sets itself up on its first tick: its routes are rotated to match the placement, the vehicle is spawned exactly as a respawn would (full fuel/ammo, stick re-pointed at it, activated), and the copy becomes owner-less (creative-only management) and disarmed.
	//
	// A copy is told apart from the original by position (and dimension): the armed block itself never spawns anything, and stays an ordinary working enemy block.
	//
	// Rotation: structure placement rotates block STATES but never block entity data, so the FACING recorded when arming, compared with the copy's own FACING, gives the number of quarter turns to apply to everything stored relative to the block. Mirroring cannot be told apart from a rotation this way (only one direction is recorded) and is not supported - placing a template mirrored reproduces it rotated instead.

	private boolean templateArmed;
	private class_2338 templateArmedPos;
	private String templateArmedDimension;
	private class_2350 templateArmedFacing;

	public boolean enemyvehicleaddon$isTemplateArmed() {
		return this.templateArmed;
	}

	/** Returns null on success, or the translation key of the reason arming is refused. */
	public String enemyvehicleaddon$armTemplate(class_3218 world) {
		if (!(this.method_5438(0).method_7909() instanceof DroneControlStickItem)) {
			return "message.enemyvehicleaddon.template.no_stick";
		}
		if (this.respawnVehicleId == null) {
			// Recorded the first time the bound vehicle is seen - see the respawn section.
			return "message.enemyvehicleaddon.template.no_vehicle";
		}
		if (!this.method_5438(1).method_7960()) {
			// A route book stores ABSOLUTE coordinates, which cannot follow a template to another place. Taking it out copies its route into this block (the prerequisite mod's own behavior), where it is stored relative.
			return "message.enemyvehicleaddon.template.route_book";
		}
		this.templateArmed = true;
		this.templateArmedPos = this.method_11016().method_10062();
		this.templateArmedDimension = world.method_27983().method_29177().toString();
		this.templateArmedFacing = this.method_11010().method_11654(EnemyControlBlock.FACING);
		this.method_5431();
		return null;
	}

	public void enemyvehicleaddon$disarmTemplate() {
		this.templateArmed = false;
		this.templateArmedPos = null;
		this.templateArmedDimension = null;
		this.templateArmedFacing = null;
		this.method_5431();
	}

	private void enemyvehicleaddon$updateTemplatePlacement(class_3218 world, class_2680 state) {
		if (!this.templateArmed || this.templateArmedPos == null) {
			return;
		}
		String dimension = world.method_27983().method_29177().toString();
		if (this.templateArmedPos.equals(this.method_11016()) && dimension.equals(this.templateArmedDimension)) {
			return; // The armed original itself - see the template section.
		}
		int quarterTurns = Math.floorMod(enemyvehicleaddon$quarterTurnIndex(state.method_11654(EnemyControlBlock.FACING))
				- enemyvehicleaddon$quarterTurnIndex(this.templateArmedFacing), 4);
		this.enemyvehicleaddon$rotateStoredData(quarterTurns);
		this.enemyvehicleaddon$disarmTemplate();
		this.owner = null;
		this.respawnAt = -1L;
		this.respawnPoseRecordedFor = null;
		if (!(this.method_5438(0).method_7909() instanceof DroneControlStickItem)) {
			// Normally saved along with the block; recreated in case the template was saved without it.
			this.method_5447(0, new class_1799(com.example.tudursvehiclemod.item.ModItems.DRONE_CONTROL_STICK));
		}
		// Whatever the stick still points at is the ORIGINAL's vehicle - never touch it (no wreck to remove here).
		if (!this.enemyvehicleaddon$respawn(world, null)) {
			LOGGER.warn("Enemy Control Block template copy at {} could not spawn its vehicle ({}).", this.method_11016(), this.respawnVehicleId);
		}
	}

	/** NORTH=0, EAST=1, SOUTH=2, WEST=3 - clockwise quarter turns seen from above; null (never armed with a facing) counts as NORTH. */
	private static int enemyvehicleaddon$quarterTurnIndex(class_2350 direction) {
		if (direction == null) {
			return 0;
		}
		return switch (direction) {
			case field_11034 -> 1;
			case field_11035 -> 2;
			case field_11039 -> 3;
			default -> 0;
		};
	}

	/** Rotates everything stored relative to this block by quarterTurns clockwise (seen from above) about the block's centre - the routes, Home Point, return via point and parked pose. The routes' own offsets are measured from the block centre (the prerequisite mod adds 0.5 to x/z when using them), so integer offsets stay integers; the parked pose is stored from the block's corner and is converted to centre-relative for the rotation. */
	private void enemyvehicleaddon$rotateStoredData(int quarterTurns) {
		if (quarterTurns == 0) {
			return;
		}
		List<DroneWaypoint> waypoints = new ArrayList<>();
		for (DroneWaypoint waypoint : this.tudursvehiclemod$getWaypoints()) {
			waypoints.add(enemyvehicleaddon$rotate(waypoint, quarterTurns));
		}
		this.tudursvehiclemod$setWaypoints(waypoints);

		List<GroundWaypoint> groundWaypoints = new ArrayList<>();
		for (GroundWaypoint waypoint : this.tudursvehiclemod$getGroundWaypoints()) {
			int[] rotated = enemyvehicleaddon$rotate(waypoint.relX(), waypoint.relZ(), quarterTurns);
			groundWaypoints.add(new GroundWaypoint(rotated[0], rotated[1], waypoint.speedFraction(), waypoint.waitTicks()));
		}
		this.tudursvehiclemod$setGroundWaypoints(groundWaypoints);

		this.tudursvehiclemod$setHomePoint(enemyvehicleaddon$rotate(this.tudursvehiclemod$getHomePoint(), quarterTurns));
		DroneWaypoint via = this.tudursvehiclemod$getReturnViaPoint();
		if (via != null) {
			this.tudursvehiclemod$setReturnViaPoint(enemyvehicleaddon$rotate(via, quarterTurns));
		}

		if (this.respawnPose != null) {
			double x = this.respawnPose[0] - 0.5;
			double z = this.respawnPose[2] - 0.5;
			for (int i = 0; i < quarterTurns; i++) {
				double previousX = x;
				x = -z;
				z = previousX;
			}
			this.respawnPose = new double[]{x + 0.5, this.respawnPose[1], z + 0.5,
					net.minecraft.class_3532.method_15338(this.respawnPose[3] + 90.0 * quarterTurns)};
		}
		this.method_5431();
	}

	private static DroneWaypoint enemyvehicleaddon$rotate(DroneWaypoint waypoint, int quarterTurns) {
		int[] rotated = enemyvehicleaddon$rotate(waypoint.relX(), waypoint.relZ(), quarterTurns);
		return new DroneWaypoint(rotated[0], waypoint.relY(), rotated[1], waypoint.speedFraction(), waypoint.rollAngle(),
				waypoint.rollManeuverabilityMultiplier(), waypoint.turnManeuverabilityMultiplier());
	}

	/** One clockwise quarter turn (seen from above, +x east, +z south) maps (x, z) to (-z, x) - e.g. north (0, -1) to east (1, 0). Yaw follows the same turn: +90 degrees each. */
	private static int[] enemyvehicleaddon$rotate(int x, int z, int quarterTurns) {
		for (int i = 0; i < quarterTurns; i++) {
			int previousX = x;
			x = -z;
			z = previousX;
		}
		return new int[]{x, z};
	}

	// --- Owner / access ---

	public UUID enemyvehicleaddon$getOwner() {
		return this.owner;
	}

	public void enemyvehicleaddon$setOwner(UUID owner) {
		this.owner = owner;
		this.method_5431();
	}

	/** Who may open any of this block's screens (the inherited Drone Center ones included): its owner, or any player currently in creative mode (i.e. someone who could equally just replace the block). An owner-less block (no placing player) is therefore creative-only. */
	public boolean enemyvehicleaddon$canManage(class_1657 player) {
		return player.method_68878() || (this.owner != null && this.owner.equals(player.method_5667()));
	}

	// --- Enemy settings ---

	public double enemyvehicleaddon$getLeashRadius() {
		return this.leashRadius;
	}

	public List<String> enemyvehicleaddon$getWhitelist() {
		return this.whitelist;
	}

	/** Sanitises everything (a client-sent payload is not trusted): radius clamped, names stripped, blank/over-long/whitespace-containing names dropped, case-insensitive duplicates removed (first spelling kept), list capped. */
	public void enemyvehicleaddon$setEnemySettings(double radius, List<String> names) {
		this.leashRadius = Double.isFinite(radius)
				? Math.max(MIN_LEASH_RADIUS, Math.min(MAX_LEASH_RADIUS, radius)) : DEFAULT_LEASH_RADIUS;
		this.enemyvehicleaddon$setWhitelistInternal(names);
		this.method_5431();
	}

	/** Also used by EnemyControlSettingsScreen (client side) to validate a name before adding it, so both sides agree on what is accepted. */
	public static boolean enemyvehicleaddon$isAcceptableName(String name) {
		if (name == null || name.isEmpty() || name.length() > MAX_NAME_LENGTH) {
			return false;
		}
		for (int i = 0; i < name.length(); i++) {
			if (Character.isWhitespace(name.charAt(i)) || name.charAt(i) == ';') {
				return false;
			}
		}
		return true;
	}

	private void enemyvehicleaddon$setWhitelistInternal(List<String> names) {
		List<String> cleaned = new ArrayList<>();
		Set<String> lower = new LinkedHashSet<>();
		if (names != null) {
			for (String raw : names) {
				String name = raw == null ? "" : raw.strip();
				if (!enemyvehicleaddon$isAcceptableName(name)) {
					continue;
				}
				if (lower.add(name.toLowerCase(Locale.ROOT))) {
					cleaned.add(name);
				}
				if (cleaned.size() >= MAX_WHITELIST_SIZE) {
					break;
				}
			}
		}
		this.whitelist = List.copyOf(cleaned);
		this.whitelistLowerCase = Set.copyOf(lower);
	}

	@Override
	public class_2561 method_5476() {
		return class_2561.method_43471("block.enemyvehicleaddon.enemy_control");
	}

	// --- Persistence ---

	@Override
	protected void method_11014(class_11368 view) {
		super.method_11014(view);
		// See the constructor: data without this key (e.g. a block entity written by a structure template) keeps this block's AUTO_RESUME default rather than the prerequisite mod's MANUAL_REENABLE fallback.
		if (view.method_71439("AutoDisableResumeMode").isEmpty()) {
			this.tudursvehiclemod$setAutoDisableResumeMode(DroneCenterBlockEntity.AutoDisableResumeMode.AUTO_RESUME);
		}
		String ownerString = view.method_71428("EnemyOwner", "");
		UUID parsedOwner = null;
		if (!ownerString.isEmpty()) {
			try {
				parsedOwner = UUID.fromString(ownerString);
			} catch (IllegalArgumentException ignored) {
				// Corrupted value - treated as owner-less (creative-only management) rather than failing the whole load.
			}
		}
		this.owner = parsedOwner;
		this.leashRadius = view.method_71422("EnemyLeashRadius", DEFAULT_LEASH_RADIUS);
		String encoded = view.method_71428("EnemyWhitelist", "");
		this.enemyvehicleaddon$setWhitelistInternal(encoded.isEmpty() ? List.of() : List.of(encoded.split(";")));

		String vehicleId = view.method_71428("EnemyRespawnVehicle", "");
		this.respawnVehicleId = vehicleId.isEmpty() ? null : class_2960.method_12829(vehicleId);
		this.respawnPose = null;
		String[] pose = view.method_71428("EnemyRespawnPose", "").split(",");
		if (pose.length == 4) {
			try {
				this.respawnPose = new double[]{Double.parseDouble(pose[0]), Double.parseDouble(pose[1]), Double.parseDouble(pose[2]), Double.parseDouble(pose[3])};
			} catch (NumberFormatException ignored) {
				// Falls back to the Home Point - see the respawn section doc.
			}
		}
		String poseFor = view.method_71428("EnemyRespawnPoseFor", "");
		UUID parsedPoseFor = null;
		if (!poseFor.isEmpty()) {
			try {
				parsedPoseFor = UUID.fromString(poseFor);
			} catch (IllegalArgumentException ignored) {
				// Treated as "not recorded yet" - the pose is simply recorded again.
			}
		}
		this.respawnPoseRecordedFor = parsedPoseFor;
		this.respawnAt = view.method_71425("EnemyRespawnAt", -1L);
		this.pendingSetup = EnemyUnitSpec.fromJsonString(view.method_71428("EnemyPendingSetup", "")).orElse(null);

		this.templateArmed = view.method_71433("EnemyTemplateArmed", false);
		this.templateArmedPos = null;
		this.templateArmedDimension = view.method_71428("EnemyTemplateDimension", "");
		this.templateArmedFacing = class_2350.method_10168(view.method_71428("EnemyTemplateFacing", "north"));
		String[] armedPos = view.method_71428("EnemyTemplatePos", "").split(",");
		if (armedPos.length == 3) {
			try {
				this.templateArmedPos = new class_2338(Integer.parseInt(armedPos[0]), Integer.parseInt(armedPos[1]), Integer.parseInt(armedPos[2]));
			} catch (NumberFormatException ignored) {
				// Malformed: disarmed below.
			}
		}
		if (this.templateArmedPos == null || this.templateArmedFacing == null) {
			this.templateArmed = false;
		}
	}

	/** Plain strings, the same style the prerequisite mod uses for its own Drone Center data (';' can never appear in an accepted name - see enemyvehicleaddon$isAcceptableName()). */
	@Override
	protected void method_11007(class_11372 view) {
		super.method_11007(view);
		if (this.owner != null) {
			view.method_71469("EnemyOwner", this.owner.toString());
		}
		view.method_71463("EnemyLeashRadius", this.leashRadius);
		if (!this.whitelist.isEmpty()) {
			view.method_71469("EnemyWhitelist", String.join(";", this.whitelist));
		}
		if (this.respawnVehicleId != null) {
			view.method_71469("EnemyRespawnVehicle", this.respawnVehicleId.toString());
		}
		if (this.respawnPose != null) {
			view.method_71469("EnemyRespawnPose", this.respawnPose[0] + "," + this.respawnPose[1] + "," + this.respawnPose[2] + "," + this.respawnPose[3]);
		}
		if (this.respawnPoseRecordedFor != null) {
			view.method_71469("EnemyRespawnPoseFor", this.respawnPoseRecordedFor.toString());
		}
		view.method_71466("EnemyRespawnAt", this.respawnAt);
		if (this.pendingSetup != null) {
			String json = this.pendingSetup.toJsonString();
			if (json != null) {
				view.method_71469("EnemyPendingSetup", json);
			}
		}
		if (this.templateArmed && this.templateArmedPos != null && this.templateArmedFacing != null) {
			view.method_71472("EnemyTemplateArmed", true);
			view.method_71469("EnemyTemplatePos", this.templateArmedPos.method_10263() + "," + this.templateArmedPos.method_10264() + "," + this.templateArmedPos.method_10260());
			view.method_71469("EnemyTemplateDimension", this.templateArmedDimension == null ? "" : this.templateArmedDimension);
			view.method_71469("EnemyTemplateFacing", this.templateArmedFacing.method_15434());
		}
	}
}
