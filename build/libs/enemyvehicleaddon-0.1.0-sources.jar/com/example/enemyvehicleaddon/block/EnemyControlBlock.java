package com.example.enemyvehicleaddon.block;

import com.example.enemyvehicleaddon.link.EnemyLinkManager;
import com.example.enemyvehicleaddon.registry.EnemyAddonBlockEntities;
import com.example.tudursvehiclemod.block.DroneCenterBlock;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_5558;

/** Enemy Control Block - the prerequisite mod's Drone Center, reused as-is (config screen, slot UI, redstone control, chunk force-loading, cleanup on removal all come from DroneCenterBlock, and the prerequisite mod's own UseBlockCallback already dispatches to any DroneCenterBlock subclass), with only these differences:
 *
 * - its block entity is an EnemyControlBlockEntity (whose dummy pilot is an EnemyPilotEntity - see that class's doc),
 * - the placing player is recorded as its owner,
 * - it does not force-load chunks the way a Drone Center does; its vehicle is dormant unless players are near it or it is pursuing a target (see link.EnemyLinkManager),
 * - sneak + right-click opens this block's own enemy settings (whitelist, leash radius), and only the owner or a creative-mode player may operate the block at all - see EnemyControlInteraction. */
public class EnemyControlBlock extends DroneCenterBlock {

	public static final MapCodec<EnemyControlBlock> CODEC = method_54094(EnemyControlBlock::new);

	/** Which way the block was facing when placed - exists for structure templates (see EnemyControlBlockEntity's template section): every way of placing a saved structure (structure block, /place, jigsaw, WorldEdit, ...) rotates block states but never block entity data, so comparing this property with the facing recorded when the template was armed is how the relative routes stored in the block entity learn how far the structure was rotated. */
	public static final class_2754<class_2350> FACING = class_2741.field_12481;

	public EnemyControlBlock(class_2251 settings) {
		super(settings);
		this.method_9590(this.method_9595().method_11664().method_11657(FACING, class_2350.field_11043));
	}

	@Override
	protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
		super.method_9515(builder);
		builder.method_11667(FACING);
	}

	/** Faces the placing player, like a furnace. */
	@Override
	public class_2680 method_9605(class_1750 ctx) {
		return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
	}

	@Override
	protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
		return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
	}

	@Override
	protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
		return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
	}

	@Override
	protected MapCodec<? extends class_2237> method_53969() {
		return field_46280;
	}

	@Override
	public class_2586 method_10123(class_2338 pos, class_2680 state) {
		return new EnemyControlBlockEntity(pos, state);
	}

	/** DroneCenterBlock's own getTicker() only matches the DRONE_CENTER type, which this block's entity does not carry (see EnemyControlBlockEntity's constructor doc). */
	@Override
	public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
		return method_31618(type, EnemyAddonBlockEntities.ENEMY_CONTROL, EnemyControlBlockEntity::tick);
	}

	/** Drops this block's link record (EnemyLinkManager) on top of the inherited cleanup (which unlinks the vehicle if it is currently loaded - an unloaded one is caught later by its own pilot, see EnemyPilotEntity#tick()). */
	@Override
	public void method_66388(class_2680 state, class_3218 world, class_2338 pos, boolean moved) {
		super.method_66388(state, world, pos, moved);
		if (!world.method_8320(pos).method_27852(this)) {
			EnemyLinkManager.onBlockRemoved(world, pos);
		}
	}

	@Override
	public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack) {
		super.method_9567(world, pos, state, placer, itemStack);
		if (!world.method_8608() && placer instanceof class_1657 player
				&& world.method_8321(pos) instanceof EnemyControlBlockEntity blockEntity) {
			blockEntity.enemyvehicleaddon$setOwner(player.method_5667());
		}
	}
}
