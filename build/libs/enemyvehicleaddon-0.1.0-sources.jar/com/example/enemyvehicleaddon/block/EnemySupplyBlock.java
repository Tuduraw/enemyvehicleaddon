package com.example.enemyvehicleaddon.block;

import com.example.enemyvehicleaddon.registry.EnemyAddonBlockEntities;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;

/** Enemy Supply Block - refuels, rearms and repairs stationary enemy vehicles around it (see EnemySupplyBlockEntity). Placed near an Enemy Control Block's Home Point, it lets an enemy aircraft that landed to resupply (the prerequisite mod's auto-disable) take off again on its own (AUTO_RESUME, this addon's default for Enemy Control Blocks). Destroying it grounds such aircraft - a deliberate strategic target. No GUI: range and behaviour come from config/enemyvehicleaddon.json. */
public class EnemySupplyBlock extends class_2237 {

	public static final MapCodec<EnemySupplyBlock> CODEC = method_54094(EnemySupplyBlock::new);

	public EnemySupplyBlock(class_2251 settings) {
		super(settings);
	}

	@Override
	protected MapCodec<? extends class_2237> method_53969() {
		return field_46280;
	}

	@Override
	protected class_2464 method_9604(class_2680 state) {
		return class_2464.field_11458;
	}

	@Override
	public class_2586 method_10123(class_2338 pos, class_2680 state) {
		return new EnemySupplyBlockEntity(pos, state);
	}

	@Override
	public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
		return world.method_8608() ? null : method_31618(type, EnemyAddonBlockEntities.ENEMY_SUPPLY, EnemySupplyBlockEntity::tick);
	}
}
