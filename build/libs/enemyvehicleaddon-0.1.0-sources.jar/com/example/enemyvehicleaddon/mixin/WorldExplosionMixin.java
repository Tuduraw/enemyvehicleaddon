package com.example.enemyvehicleaddon.mixin;

import com.example.enemyvehicleaddon.config.EnemyAddonConfig;
import com.example.enemyvehicleaddon.link.EnemyVehicles;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** The explosion of a DESTROYED enemy vehicle: the prerequisite mod creates it with the vehicle itself as the source and ExplosionSourceType.MOB (which destroys blocks, subject to mobGriefing). Unless EnemyAddonConfig#enemyBlockDamage is on, it is re-issued with NONE and no fire - same damage and effects, no crater. Weapon explosions never reach this case (their source is the projectile, and they already use NONE - see VehicleProjectileEntityMixin). */
@Mixin(class_1937.class)
public abstract class WorldExplosionMixin {

	@Inject(method = "createExplosion(Lnet/minecraft/entity/Entity;DDDFZLnet/minecraft/world/World$ExplosionSourceType;)V",
			at = @At("HEAD"), cancellable = true)
	private void enemyvehicleaddon$noEnemyWreckBlockDamage(class_1297 entity, double x, double y, double z, float power, boolean createFire,
			class_1937.class_7867 sourceType, CallbackInfo ci) {
		if (sourceType == class_1937.class_7867.field_40888 || EnemyAddonConfig.get().enemyBlockDamage || !EnemyVehicles.isEnemy(entity)) {
			return;
		}
		ci.cancel();
		((class_1937) (Object) this).method_8537(entity, x, y, z, power, false, class_1937.class_7867.field_40888);
	}
}
