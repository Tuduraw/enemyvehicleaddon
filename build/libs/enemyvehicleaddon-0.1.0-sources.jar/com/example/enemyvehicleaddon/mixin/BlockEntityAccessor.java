package com.example.enemyvehicleaddon.mixin;

import net.minecraft.class_2586;
import net.minecraft.class_2591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Lets EnemyControlBlockEntity replace the block entity type its superclass constructor hardcodes - see that class's own constructor doc. */
@Mixin(class_2586.class)
public interface BlockEntityAccessor {

	@Mutable
	@Accessor("type")
	void enemyvehicleaddon$setType(class_2591<?> type);
}
