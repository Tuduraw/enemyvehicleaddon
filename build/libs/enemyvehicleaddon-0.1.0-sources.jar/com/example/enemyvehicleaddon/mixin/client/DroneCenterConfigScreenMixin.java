package com.example.enemyvehicleaddon.mixin.client;

import com.example.enemyvehicleaddon.block.EnemyControlBlock;
import com.example.enemyvehicleaddon.network.EnemyControlSettingsRequestPayload;
import com.example.tudursvehiclemod.client.screen.DroneCenterConfigScreen;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds an "エネミー設定" button to the bottom of the prerequisite mod's own Drone Center config screen, but only when that screen is showing an Enemy Control Block - this is now the only way to reach EnemyControlSettingsScreen.
 *
 * Originally this used sneak + right-click on the block itself, but that hijacked the exact interaction vanilla uses to let a player place a block against the Enemy Control Block while sneaking (this same class of conflict is exactly why the prerequisite mod's own DroneCenterBlock#tudursvehiclemod$handleUse() explicitly PASSes while the player is sneaking, opening its config screen only on an ordinary click - see that method's own doc). A button inside the screen that ordinary click already opens has no such conflict.
 *
 * remap = false at class level (DroneCenterConfigScreen and its own init() are the prerequisite mod's, not Minecraft's); TAIL is safe regardless of how many buttons the prerequisite mod's own init() adds above this addon's own button, since this always ends up last. */
@Mixin(value = DroneCenterConfigScreen.class, remap = false)
public abstract class DroneCenterConfigScreenMixin extends class_437 {

	protected DroneCenterConfigScreenMixin(class_2561 title) {
		super(title);
	}

	@Inject(method = "init", at = @At("TAIL"))
	private void enemyvehicleaddon$addEnemySettingsButton(CallbackInfo ci) {
		DroneCenterConfigScreenAccessor accessor = (DroneCenterConfigScreenAccessor) this;
		class_2338 pos = new class_2338(accessor.enemyvehicleaddon$getBlockX(), accessor.enemyvehicleaddon$getBlockY(), accessor.enemyvehicleaddon$getBlockZ());
		class_310 client = class_310.method_1551();
		if (client.field_1687 == null || !(client.field_1687.method_8320(pos).method_26204() instanceof EnemyControlBlock)) {
			return;
		}
		int centerX = this.field_22789 / 2;
		// Appended after the prerequisite mod's own last button (Close, at startY+172 - see that screen's own init()).
		int startY = this.field_22790 / 2 - 90;
		this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.enemyvehicleaddon.enemy_settings.open_button"),
				button -> ClientPlayNetworking.send(new EnemyControlSettingsRequestPayload(pos.method_10263(), pos.method_10264(), pos.method_10260()))
		).method_46434(centerX - 100, startY + 196, 200, 20).method_46431());
	}
}
