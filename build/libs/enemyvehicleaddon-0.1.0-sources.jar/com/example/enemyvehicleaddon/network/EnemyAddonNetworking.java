package com.example.enemyvehicleaddon.network;

import com.example.enemyvehicleaddon.block.EnemyControlBlockEntity;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class EnemyAddonNetworking {

	/** Same reach a vanilla container screen is allowed (8 blocks). */
	private static final double MAX_EDIT_DISTANCE_SQUARED = 64.0;

	private EnemyAddonNetworking() {
	}

	public static void register() {
		PayloadTypeRegistry.playS2C().register(EnemyControlSettingsOpenPayload.ID, EnemyControlSettingsOpenPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(EnemyControlSettingsUpdatePayload.ID, EnemyControlSettingsUpdatePayload.CODEC);
		PayloadTypeRegistry.playC2S().register(EnemyControlSettingsRequestPayload.ID, EnemyControlSettingsRequestPayload.CODEC);

		// Sent when the player presses the button DroneCenterConfigScreenMixin adds to the prerequisite mod's own config screen - see that payload's own doc.
		ServerPlayNetworking.registerGlobalReceiver(EnemyControlSettingsRequestPayload.ID, (payload, context) ->
				context.server().execute(() -> {
					class_3222 player = context.player();
					class_2338 pos = new class_2338(payload.x(), payload.y(), payload.z());
					if (player.method_5707(class_243.method_24953(pos)) > MAX_EDIT_DISTANCE_SQUARED) {
						return;
					}
					if (player.method_51469().method_8321(pos) instanceof EnemyControlBlockEntity blockEntity) {
						if (!blockEntity.enemyvehicleaddon$canManage(player)) {
							player.method_7353(class_2561.method_43471("message.enemyvehicleaddon.no_permission"), true);
							return;
						}
						ServerPlayNetworking.send(player, new EnemyControlSettingsOpenPayload(
								pos.method_10263(), pos.method_10264(), pos.method_10260(),
								blockEntity.enemyvehicleaddon$getLeashRadius(),
								blockEntity.enemyvehicleaddon$getWhitelist(),
								blockEntity.enemyvehicleaddon$isTemplateArmed()));
					}
				}));

		ServerPlayNetworking.registerGlobalReceiver(EnemyControlSettingsUpdatePayload.ID, (payload, context) ->
				context.server().execute(() -> {
					class_3222 player = context.player();
					class_2338 pos = new class_2338(payload.x(), payload.y(), payload.z());
					// Re-checked here, not just when the screen was opened: the payload could come from a modified client, or from a player who has since walked away / lost creative mode.
					if (player.method_5707(class_243.method_24953(pos)) > MAX_EDIT_DISTANCE_SQUARED) {
						return;
					}
					if (player.method_51469().method_8321(pos) instanceof EnemyControlBlockEntity blockEntity
							&& blockEntity.enemyvehicleaddon$canManage(player)) {
						blockEntity.enemyvehicleaddon$setEnemySettings(payload.leashRadius(), payload.whitelist());
						// Template arming is saved together with the rest (see EnemyControlBlockEntity's template section); arming can be refused, so the outcome is reported either way.
						if (payload.templateArmed() != blockEntity.enemyvehicleaddon$isTemplateArmed()) {
							if (payload.templateArmed()) {
								String refusal = blockEntity.enemyvehicleaddon$armTemplate((net.minecraft.class_3218) player.method_51469());
								player.method_7353(class_2561.method_43471(refusal != null ? refusal : "message.enemyvehicleaddon.template.armed"), true);
							} else {
								blockEntity.enemyvehicleaddon$disarmTemplate();
								player.method_7353(class_2561.method_43471("message.enemyvehicleaddon.template.disarmed"), true);
							}
						}
					}
				}));
	}
}
