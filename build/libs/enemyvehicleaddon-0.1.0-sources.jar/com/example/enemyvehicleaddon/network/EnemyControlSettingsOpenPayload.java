package com.example.enemyvehicleaddon.network;

import com.example.enemyvehicleaddon.EnemyVehicleAddon;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Server -> client: open the enemy settings screen for the Enemy Control Block at (x, y, z), pre-filled with its current values. */
public record EnemyControlSettingsOpenPayload(int x, int y, int z, double leashRadius, List<String> whitelist, boolean templateArmed) implements class_8710 {

	public static final class_8710.class_9154<EnemyControlSettingsOpenPayload> ID =
			new class_8710.class_9154<>(class_2960.method_60655(EnemyVehicleAddon.MOD_ID, "enemy_control_settings_open"));

	public static final class_9139<class_9129, EnemyControlSettingsOpenPayload> CODEC = class_9139.method_58025(
			class_9135.field_48550, EnemyControlSettingsOpenPayload::x,
			class_9135.field_48550, EnemyControlSettingsOpenPayload::y,
			class_9135.field_48550, EnemyControlSettingsOpenPayload::z,
			class_9135.field_48553, EnemyControlSettingsOpenPayload::leashRadius,
			class_9135.field_48554.method_56433(class_9135.method_56363()), EnemyControlSettingsOpenPayload::whitelist,
			class_9135.field_48547, EnemyControlSettingsOpenPayload::templateArmed,
			EnemyControlSettingsOpenPayload::new
	);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
