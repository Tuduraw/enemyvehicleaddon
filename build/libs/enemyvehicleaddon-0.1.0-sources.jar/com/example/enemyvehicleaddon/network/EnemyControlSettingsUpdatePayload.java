package com.example.enemyvehicleaddon.network;

import com.example.enemyvehicleaddon.EnemyVehicleAddon;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Client -> server: the full, edited enemy settings for the Enemy Control Block at (x, y, z). Not trusted - see EnemyAddonNetworking's handler and EnemyControlBlockEntity#enemyvehicleaddon$setEnemySettings(). */
public record EnemyControlSettingsUpdatePayload(int x, int y, int z, double leashRadius, List<String> whitelist, boolean templateArmed) implements class_8710 {

	public static final class_8710.class_9154<EnemyControlSettingsUpdatePayload> ID =
			new class_8710.class_9154<>(class_2960.method_60655(EnemyVehicleAddon.MOD_ID, "enemy_control_settings_update"));

	public static final class_9139<class_9129, EnemyControlSettingsUpdatePayload> CODEC = class_9139.method_58025(
			class_9135.field_48550, EnemyControlSettingsUpdatePayload::x,
			class_9135.field_48550, EnemyControlSettingsUpdatePayload::y,
			class_9135.field_48550, EnemyControlSettingsUpdatePayload::z,
			class_9135.field_48553, EnemyControlSettingsUpdatePayload::leashRadius,
			class_9135.field_48554.method_56433(class_9135.method_56363()), EnemyControlSettingsUpdatePayload::whitelist,
			class_9135.field_48547, EnemyControlSettingsUpdatePayload::templateArmed,
			EnemyControlSettingsUpdatePayload::new
	);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
