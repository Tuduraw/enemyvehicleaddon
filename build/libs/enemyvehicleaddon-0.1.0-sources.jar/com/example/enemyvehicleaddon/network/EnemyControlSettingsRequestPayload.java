package com.example.enemyvehicleaddon.network;

import com.example.enemyvehicleaddon.EnemyVehicleAddon;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/** Client -> server: "open the enemy settings screen for the Enemy Control Block at (x, y, z)", sent when the player presses the button EnemyDroneCenterConfigScreenMixin adds to the prerequisite mod's own Drone Center config screen (see that mixin's own doc for why this replaced the earlier sneak+right-click shortcut). Mirrors the request/response shape of the prerequisite mod's own DummyPilotConfigRequestPayload/DummyPilotConfigOpenPayload pair. The server re-checks EnemyControlBlockEntity#enemyvehicleaddon$canManage() before replying (this payload only ever means "I clicked the button" - not "I am allowed"), and stays silent (see EnemyAddonNetworking's handler) rather than opening anything for a player who isn't. */
public record EnemyControlSettingsRequestPayload(int x, int y, int z) implements class_8710 {

	public static final class_8710.class_9154<EnemyControlSettingsRequestPayload> ID =
			new class_8710.class_9154<>(class_2960.method_60655(EnemyVehicleAddon.MOD_ID, "enemy_control_settings_request"));

	public static final class_9139<class_9129, EnemyControlSettingsRequestPayload> CODEC = class_9139.method_56436(
			class_9135.field_48550, EnemyControlSettingsRequestPayload::x,
			class_9135.field_48550, EnemyControlSettingsRequestPayload::y,
			class_9135.field_48550, EnemyControlSettingsRequestPayload::z,
			EnemyControlSettingsRequestPayload::new
	);

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return ID;
	}
}
